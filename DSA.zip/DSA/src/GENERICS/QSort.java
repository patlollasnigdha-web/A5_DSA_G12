package GENERICS;
import java.util.*;

public class QSort
{
    static void QuickSort(int[] A, int LI, int RI)
    {
        int j;
        if (LI < RI)
        {
            j = Divide(A, LI, RI);
            QuickSort(A, LI, j - 1);
            QuickSort(A, j + 1, RI);
        }
    }

    static int Divide(int[] A, int LI, int RI)
    {
        int Pivot, j, i, Temp;
        Pivot = A[LI];
        i = LI;
        j = RI + 1;

        while (true)
        {
            do {
                i++;
            } while (i <= RI && A[i] < Pivot);

            do {
                j--;
            } while (A[j] > Pivot);

            if (i >= j)
                break;

            Temp = A[i];
            A[i] = A[j];
            A[j] = Temp;
        }

        Temp = A[LI];
        A[LI] = A[j];
        A[j] = Temp;

        return j;
    }

    static void PrintArray(int[] A)
    {
        for (int x : A)
        {
            System.out.print(x + "  ");
        }
    }

    public static void main(String[] args)
    {
        Scanner SC = new Scanner(System.in);
        System.out.println("Enter Size of the Array ");
        int N = SC.nextInt();

        System.out.println("Enter " + N + " Integer Elements ");
        int[] A1 = new int[N];

        for (int i = 0; i < N; i++)
            A1[i] = SC.nextInt();

        System.out.println("Elements of Array Before Sorting ");
        PrintArray(A1);

        QuickSort(A1, 0, A1.length - 1);

        System.out.println("\nElements of Array After Sorting ");
        PrintArray(A1);
    }
}