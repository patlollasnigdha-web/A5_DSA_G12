package GENERICS;

import java.util.Scanner;

public class linear_search {

    public static <T> int linearsearch(T[] A, T sval) {
        for (int i = 0; i < A.length; i++) {
            if (A[i].equals(sval)) {
                return i;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        int n, index = -1;
        Scanner ob = new Scanner(System.in);

        System.out.println("Enter size of array");
        n = ob.nextInt();

        System.out.println("1.Integer\n2.Double\n3.String");
        System.out.println("Enter the choice");
        int opt = ob.nextInt();

        switch (opt) {

            case 1:
                Integer[] A1 = new Integer[n];
                System.out.println("Enter " + n + " elements");
                for (int i = 0; i < n; i++)
                    A1[i] = ob.nextInt();

                System.out.println("Enter search element");
                Integer S1 = ob.nextInt();

                index = linearsearch(A1, S1);
                break;

            case 2:
                Double[] A2 = new Double[n];
                System.out.println("Enter " + n + " elements");
                for (int i = 0; i < n; i++)
                    A2[i] = ob.nextDouble();

                System.out.println("Enter search element");
                Double S2 = ob.nextDouble();

                index = linearsearch(A2, S2);
                break;

            case 3:
                String[] A3 = new String[n];
                System.out.println("Enter " + n + " elements");
                for (int i = 0; i < n; i++)
                    A3[i] = ob.next();

                System.out.println("Enter search element");
                String S3 = ob.next();

                index = linearsearch(A3, S3);
                break;

            default:
                System.out.println("Invalid choice");
        }

        if (index == -1)
            System.out.println("Element not found");
        else
            System.out.println("Element found at index " + index);
    }
}
