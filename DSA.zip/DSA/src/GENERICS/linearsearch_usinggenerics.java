package GENERICS;
import java.util.Scanner;

	class ls<T>{
		public int linear_search (T[] a,T svalue){
			for(int i=0;i<a.length;i++) {
				if(a[i].equals(svalue)) {
					return i;
				}
			}
			return -1;
		}
	}
	public class linearsearch_usinggenerics {
		public static void main(String[] args) {
			int index=0,n,opt;
			System.out.println("enter the size of an array");
			Scanner sc= new Scanner(System.in);
			n=sc.nextInt();
			System.out.println(" 1) integer \n 2)double \n 3) string");
			System.out.println("enter your choice");
			opt=sc.nextInt();
			switch(opt) {
			case 1:
				Integer[] a1=new Integer[n];
			System.out.println("enter " +n+ " integer");
			for(int i=0;i<n;i++) {
				a1[i] = sc.nextInt();
			}
			System.out.println("enter search value");
			int s1=sc.nextInt();
			ls<Integer> objI=new ls<Integer>();
			index=objI.linear_search(a1,s1);
			break;
			case 2:
				Double[] a2=new Double[n];
				System.out.println("enter"+n+"double value");
				for(int i=0;i<n;i++) {
					a2[i] = sc.nextDouble();
				}
				System.out.println("enter search value");
				Double s2=sc.nextDouble();
				ls<Double> objD=new ls<Double>();
				index=objD.linear_search(a2,s2);
				break;
			case 3:
			String[] a3=new String[n];
			System.out.println("enter"+ n + "String value");
			for(int i=0;i<n;i++) {
				a3[i] = sc.next();
			}
			System.out.println("enter search value");
			String s3=sc.next();
			ls<String> objS=new ls<String>();
			index=objS.linear_search(a3,s3);
			break;
			}
		
			if(index==-1) { 
				System.out.println("search element not found");
			}else {
	System.out.println("elements found at" +index+ "index");
			}
	}
		}