package GENERICS;
public class generic_methods {
	public static void main(String [] args) {
		Integer[] A1= {10,20,30,40};
		Double [] A2= {10.2,20.5,30.6,40.8};
		String [] A3 = {"snigdha","reddy","patlolla"};
		System.out.println("elements of integers in array");
		print(A1);
		System.out.println("elements of double in array");
		print(A2);
		System.out.println("elements of string in array");
		print(A3);		
	}
	static<G> void print(G[] A) {
		for(int i=0;i<A.length;i++) {
			System.out.print(A[i]+" ");
		}
	}

}
