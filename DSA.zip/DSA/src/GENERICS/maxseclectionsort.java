package GENERICS;
import java.util.Scanner;

class MaxSelection<T extends Comparable<T>> {

    public void selectionsort(T[] a) {
        long stime = System.nanoTime();

        for (int iteration=1,j = a.length - 1; iteration< a.length; iteration++,j--) {
            T max_value = a[0];
            int max_index = 0;

            for (int i = 1; i <= j; i++) {
                if (a[i].compareTo(max_value) > 0) {
                    max_value = a[i];
                    max_index = i;
                }
            }

            a[max_index] = a[j];
            a[j] = max_value;
        }

        long etime = System.nanoTime();
        long D = etime - stime;
        System.out.println("\nDuration of execution: " + D + " ns");
    }

    public void printarray(T[] a) {
        for (T x : a) {
            System.out.print(x + " ");
        }
        System.out.println();
    }
}

public class maxseclectionsort{
    public static void main(String[] args) {

        int n, opt;
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the size of the array:");
        n = sc.nextInt();

        System.out.println("1) Integer \n2) Double \n3) String");
        System.out.println("Enter the choice:");
        opt = sc.nextInt();

        switch (opt) {

            case 1:
                Integer[] a1 = new Integer[n];
                System.out.println("Enter " + n + " Integer values:");
                for (int i = 0; i < n; i++)
                    a1[i] = sc.nextInt();

                MaxSelection<Integer> objI = new MaxSelection<>();
                System.out.println("Elements before sorting:");
                objI.printarray(a1);

                objI.selectionsort(a1);

                System.out.println("Elements after sorting:");
                objI.printarray(a1);
                break;

            case 2:
                Double[] a2 = new Double[n];
                System.out.println("Enter " + n + " Double values:");
                for (int i = 0; i < n; i++)
                    a2[i] = sc.nextDouble();

                MaxSelection<Double> objD = new MaxSelection<>();
                System.out.println("Elements before sorting:");
                objD.printarray(a2);

                objD.selectionsort(a2);

                System.out.println("Elements after sorting:");
                objD.printarray(a2);
                break;

            case 3:
                String[] a3 = new String[n];
                System.out.println("Enter " + n + " String values:");
                for (int i = 0; i < n; i++)
                    a3[i] = sc.next();

                MaxSelection<String> objS = new MaxSelection<>();
                System.out.println("Elements before sorting:");
                objS.printarray(a3);

                objS.selectionsort(a3);

                System.out.println("Elements after sorting:");
                objS.printarray(a3);
                break;

            default:
                System.out.println("Invalid option!");
        }

        sc.close();
    }
}
