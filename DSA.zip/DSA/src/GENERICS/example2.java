package GENERICS;

public class example2 {
	static<a,n> void display(a b,n c) {
		System.out.println("value of b:"+b );
		System.out.println("value of c: "+c);
	}
	public static void main(String[]args) {
		display("snigdha",7.8);
		display(10.6,99);
		display(true,"lol");
	}
	}