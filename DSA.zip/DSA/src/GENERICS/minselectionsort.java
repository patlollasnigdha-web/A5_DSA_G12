package GENERICS;
import java.util.Scanner;

class MinSelection<T extends Comparable<T>> {

    public void selectionsort(T[] a) {
        long stime = System.nanoTime();

        for (int iteration=1,j=0; iteration<a.length;iteration++,j++) {
            T min_value = a[j];
            int min_index = j;

            for (int i = j ; i < a.length; i++) {
                if (a[i].compareTo(min_value) < 0) {
                    min_value = a[i];
                    min_index = i;
                }
            }

            a[min_index] = a[j];
            a[j] = min_value;
        }

        long etime = System.nanoTime();
        long D = etime - stime;
        System.out.println("\nDuration of execution: " + D + " ns");
    }

    public void printarray(T[] a) {
        for (T x : a) {
            System.out.print(x + " ");
        }
        System.out.println();
    }
}

public class minselectionsort {
    public static void main(String[] args) {

        int n, opt;
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the size of the array:");
        n = sc.nextInt();

        System.out.println("1) Integer \n2) Double \n3) String");
        System.out.println("Enter the choice:");
        opt = sc.nextInt();

        switch (opt) {

            case 1:
                Integer[] a1 = new Integer[n];
                System.out.println("Enter " + n + " Integer values:");
                for (int i = 0; i < n; i++)
                    a1[i] = sc.nextInt();

                MinSelection<Integer> objI = new MinSelection<>();
                System.out.println("Elements before sorting:");
                objI.printarray(a1);

                objI.selectionsort(a1);

                System.out.println("Elements after sorting:");
                objI.printarray(a1);
                break;

            case 2:
                Double[] a2 = new Double[n];
                System.out.println("Enter " + n + " Double values:");
                for (int i = 0; i < n; i++)
                    a2[i] = sc.nextDouble();

                MinSelection<Double> objD = new MinSelection<>();
                System.out.println("Elements before sorting:");
                objD.printarray(a2);

                objD.selectionsort(a2);

                System.out.println("Elements after sorting:");
                objD.printarray(a2);
                break;

            case 3:
                String[] a3 = new String[n];
                System.out.println("Enter " + n + " String values:");
                for (int i = 0; i < n; i++)
                    a3[i] = sc.next();

                MinSelection<String> objS = new MinSelection<>();
                System.out.println("Elements before sorting:");
                objS.printarray(a3);

                objS.selectionsort(a3);

                System.out.println("Elements after sorting:");
                objS.printarray(a3);
                break;

            default:
                System.out.println("Invalid option!");
        }

        sc.close();
    }
}