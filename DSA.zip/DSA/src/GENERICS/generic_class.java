package GENERICS;

class hello<tp1>{
	void display(tp1 a) {
		System.out.println("value is "+a);
	}
	public class generic_class {
		public static void main(String[] args ) {
			hello<Integer> obI = new hello<Integer>();
			hello<Double> obD = new hello<Double>();
			hello<String> obS = new hello<String>();
			obI.display(10);
			obD.display(20.5);
			obS.display("snigdha");
		}
	}
}