package GENERICS;

public class example1 {
	static <meghana> void display(meghana a) {
		System.out.println("value:" +a);
	}
	public static void main(String[]args) {
		display(10);
		display("snigdha");
		display(true);
	}
	}