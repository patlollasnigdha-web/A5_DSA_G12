package assignment;

import java.util.Scanner;

public class A1 {
    public static void main(String[] args) {
        Scanner ob = new Scanner(System.in);

        int n = ob.nextInt();
        int X = 0;

        for (int i = 1; X<= n; i++) {
            X = X + i;
        }
        System.out.println(X);
    }
}
