package linked_lists;
import java.util.*;

class DLLNode {
    int data;
    DLLNode next, prev;

    DLLNode(int data) {
        this.data = data;
        next = prev = null;
    }
}

class DLL {

    DLLNode head = null;
    DLLNode tail = null;
    DLLNode CNode;   
    Scanner sc = new Scanner(System.in);

    boolean isEmpty() {
        return head == null;
    }

    int countNodes() {
        int count = 0;
        CNode = head;
        while (CNode != null) {
            count++;
            CNode = CNode.next;
        }
        return count;
    }

    // -------- CREATE --------
    void createList() {
        String choice;
        do {
            System.out.println("Enter data:");
            int data = sc.nextInt();
            DLLNode newNode = new DLLNode(data);

            if (isEmpty()) {
                head = tail = newNode;
            } else {
                tail.next = newNode;
                newNode.prev = tail;
                tail = newNode;
            }

            System.out.println("Enter Y/y to add another node:");
            choice = sc.next();

        } while (choice.equalsIgnoreCase("y"));
    }

    
    void display() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }

        CNode = head;
        while (CNode != null) {
            System.out.print(CNode.data + " <-> ");
            CNode = CNode.next;
        }
        System.out.println("null");
    }

    void displayReverse() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }

        CNode = tail;
        while (CNode != null) {
            System.out.print(CNode.data + " <-> ");
            CNode = CNode.prev;
        }
        System.out.println("null");
    }

   
    void addBegin() {
        System.out.println("Enter data:");
        int data = sc.nextInt();
        DLLNode newNode = new DLLNode(data);

        if (isEmpty()) {
            head = tail = newNode;
        } else {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }

        System.out.println("Node added at beginning");
    }

    void addLast() {
        System.out.println("Enter data:");
        int data = sc.nextInt();
        DLLNode newNode = new DLLNode(data);

        if (isEmpty()) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }

        System.out.println("Node added at end");
    }

    void addMiddle() {
        System.out.println("Enter position:");
        int pos = sc.nextInt();

        if (pos < 1 || pos > countNodes() + 1) {
            System.out.println("Invalid position");
            return;
        }

        if (pos == 1) {
            addBegin();
        } else if (pos == countNodes() + 1) {
            addLast();
        } else {
            System.out.println("Enter data:");
            int data = sc.nextInt();
            DLLNode newNode = new DLLNode(data);

            CNode = head;
            for (int i = 1; i < pos - 1; i++) {
                CNode = CNode.next;
            }

            newNode.next = CNode.next;
            newNode.prev = CNode;
            CNode.next.prev = newNode;
            CNode.next = newNode;

            System.out.println("Node inserted at position " + pos);
        }
    }

    
    void deleteBegin() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }

        CNode = head;
        head = head.next;

        if (head != null)
            head.prev = null;
        else
            tail = null;

        System.out.println(CNode.data + " deleted from beginning");
    }

    void deleteLast() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }

        CNode = tail;
        tail = tail.prev;

        if (tail != null)
            tail.next = null;
        else
            head = null;

        System.out.println(CNode.data + " deleted from end");
    }

    void deleteMiddle() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }

        System.out.println("Enter position:");
        int pos = sc.nextInt();

        if (pos < 1 || pos > countNodes()) {
            System.out.println("Invalid position");
        } else if (pos == 1) {
            deleteBegin();
        } else if (pos == countNodes()) {
            deleteLast();
        } else {

            CNode = head;
            for (int i = 1; i < pos; i++) {
                CNode = CNode.next;
            }

            CNode.prev.next = CNode.next;
            CNode.next.prev = CNode.prev;

            System.out.println(CNode.data + " deleted from position " + pos);
        }
    }

    // -------- SEARCH --------
    void search() {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }

        System.out.println("Enter data to search:");
        int data = sc.nextInt();

        CNode = head;
        int pos = 1;
        boolean found = false;

        while (CNode != null) {
            if (CNode.data == data) {
                found = true;
                break;
            }
            CNode = CNode.next;
            pos++;
        }

        if (found)
            System.out.println(data + " found at position " + pos);
        else
            System.out.println("Data not found");
    }

   
    void findMin() {
        if (isEmpty()) return;

        CNode = head;
        int min = CNode.data;

        while (CNode != null) {
            if (CNode.data < min)
                min = CNode.data;
            CNode = CNode.next;
        }

        System.out.println("Minimum value: " + min);
    }

    void findMax() {
        if (isEmpty()) return;

        CNode = head;
        int max = CNode.data;

        while (CNode != null) {
            if (CNode.data > max)
                max = CNode.data;
            CNode = CNode.next;
        }

        System.out.println("Maximum value: " + max);
    }

    void findSum() {
        if (isEmpty()) return;

        int sum = 0;
        CNode = head;

        while (CNode != null) {
            sum += CNode.data;
            CNode = CNode.next;
        }

        System.out.println("Sum: " + sum);
    }

    void findAverage() {
        if (isEmpty()) return;

        int sum = 0, count = 0;
        CNode = head;

        while (CNode != null) {
            sum += CNode.data;
            count++;
            CNode = CNode.next;
        }

        double avg = (double) sum / count;
        System.out.println("Average: " + avg);
    }
}

public class double_linked_lists {

    public static void main(String[] args) {

        DLL list = new DLL();

        list.createList();
        list.display();
        list.displayReverse();

        list.addBegin();
        list.addLast();
        list.addMiddle();
        list.display();

        list.deleteBegin();
        list.deleteLast();
        list.deleteMiddle();
        list.display();

        list.search();

        list.findMin();
        list.findMax();
        list.findSum();
        list.findAverage();
    }
}
