package linked_lists;
class CircularLinkedList {

    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    Node head = null;

    // -------- ADD BEGIN --------
    void addBegin(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            newNode.next = head;
            return;
        }

        Node temp = head;
        while (temp.next != head) {
            temp = temp.next;
        }

        newNode.next = head;
        temp.next = newNode;
        head = newNode;
    }

    // -------- ADD LAST --------
    void addLast(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            newNode.next = head;
            return;
        }

        Node temp = head;
        while (temp.next != head) {
            temp = temp.next;
        }

        temp.next = newNode;
        newNode.next = head;
    }

    // -------- ADD AT POSITION --------
    void addPos(int data, int pos) {
        if (pos == 1) {
            addBegin(data);
            return;
        }

        Node newNode = new Node(data);
        Node temp = head;

        for (int i = 1; i < pos - 1 && temp.next != head; i++) {
            temp = temp.next;
        }

        newNode.next = temp.next;
        temp.next = newNode;
    }

    // -------- DELETE BEGIN --------
    void deleteBegin() {
        if (head == null) return;

        if (head.next == head) {
            head = null;
            return;
        }

        Node temp = head;
        while (temp.next != head) {
            temp = temp.next;
        }

        head = head.next;
        temp.next = head;
    }

    // -------- DELETE LAST --------
    void deleteLast() {
        if (head == null) return;

        if (head.next == head) {
            head = null;
            return;
        }

        Node temp = head;
        Node prev = null;

        while (temp.next != head) {
            prev = temp;
            temp = temp.next;
        }

        prev.next = head;
    }

    // -------- DELETE MIDDLE (POSITION) --------
    void deletePos(int pos) {
        if (head == null) return;

        if (pos == 1) {
            deleteBegin();
            return;
        }

        Node temp = head;
        Node prev = null;

        for (int i = 1; i < pos && temp.next != head; i++) {
            prev = temp;
            temp = temp.next;
        }

        if (prev != null)
            prev.next = temp.next;
    }

    // -------- DISPLAY --------
    void display() {
        if (head == null) {
            System.out.println("Empty List");
            return;
        }

        Node temp = head;
        do {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        } while (temp != head);

        System.out.println("(head)");
    }


public class circular_linked_list {

    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();

        list.addBegin(20);
        list.addBegin(10);
        list.addLast(40);
        list.addPos(30, 3);

        list.display();

        list.deleteBegin();
        list.deleteLast();
        list.deletePos(2);

        list.display();
    }
}
}