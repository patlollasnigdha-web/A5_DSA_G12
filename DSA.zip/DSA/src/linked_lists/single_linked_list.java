package linked_lists;

import java.util.*;
class SLLNode{
	int Data;
	SLLNode Next;
}
class SingleLinkedList{
	SLLNode Head = null,NewNode = null,CNode = null,DelNode;
	void CreateList() {
		System.out.println("Enter number of nodes");
		Scanner sc = new Scanner(System.in);
		int c = sc.nextInt();
		for(int i=1;i<=c;i++) {
			NewNode = new SLLNode();
			System.out.println("Enter the data");
			NewNode.Data = sc.nextInt();
			NewNode.Next = null;
			if(Head==null)
				Head = NewNode;
			else {
				CNode = Head;
				while(CNode.Next!=null)
					CNode = CNode.Next;
				CNode.Next = NewNode;
			}
		}
		System.out.println("List is created successfully");
		Display();
	}
	void Display() {
		System.out.println();
		if(Head==null)
			System.out.println("List is empty");
		else {
			CNode = Head;
			do{
				System.out.print(CNode.Data);
				if (CNode.Next!=null)
					System.out.print(" --> ");
				CNode = CNode.Next;
			}
			while(CNode!=null);
			System.out.println();
		}
	}
	int CountNodes() {
		int count = 0;
		CNode = Head;
		while(CNode!=null) {
			count++;
			CNode = CNode.Next;
		}
		System.out.println("Total nodes = " + count);
		return count;
	}
	void AddBegin() {
		NewNode = new SLLNode();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the data");
		NewNode.Data = sc.nextInt();
		NewNode.Next = Head;
		Head = NewNode;
		System.out.println("New Node is added at the beginning of the linked list");
		Display();
	}
	void AddEnd() {
		NewNode = new SLLNode();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the data");
		NewNode.Data = sc.nextInt();
		NewNode.Next = null;
		if(Head==null)
			Head = NewNode;
		else {
			CNode = Head;
			while(CNode.Next!=null)
				CNode = CNode.Next;
			CNode.Next = NewNode;
		}
		System.out.println("New Node is added at the end of the linked list");
		Display();
	}
	void AddMiddle() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the position");
		int pos = sc.nextInt();
		if(pos<1 || pos>CountNodes()+1) {
			System.out.println("Invalid position");
			return;
		}
		NewNode = new SLLNode();
		System.out.println("Enter the data");
		NewNode.Data = sc.nextInt();
		if(pos==1) {
			NewNode.Next = Head;
			Head = NewNode;
		}
		else {
			CNode = Head;
			for(int i=1;i<pos-1;i++)
				CNode = CNode.Next;
			NewNode.Next = CNode.Next;
			CNode.Next = NewNode;
		}
		System.out.println("New Node is added at the middle of the linked list");
		Display();
	}
	void DelBegin() {
		if(Head==null)
			System.out.println("Linked list is empty");
		else {
			DelNode = Head;
			Head = Head.Next;
			System.out.println(DelNode.Data + " is deleted");
			DelNode.Next = null;
			DelNode = null;
		}
		Display();
	}
	void DelLast() {
		if(Head==null)
			System.out.println("Linked list is empty");
		else if(Head.Next==null) {
			System.out.println(Head.Data + " is deleted");
			Head = null;
		}
		else {
			CNode = Head;
			while(CNode.Next.Next!=null)
				CNode = CNode.Next;
			DelNode = CNode.Next;
			CNode.Next = null;
			System.out.println(DelNode.Data + " is deleted");
			DelNode = null;
		}
		Display();
	}
	void DelMiddle() {
		if(Head==null) {
			System.out.println("Linked list is empty");
			return;
		}
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter node number to delete");
		int N = sc.nextInt();
		if(N<1 || N>CountNodes()) {
			System.out.println("Invalid node number");
			return;
		}
		if(N==1) {
			DelBegin();
			return;
		}
		CNode = Head;
		for(int i=1;i<N-1;i++)
			CNode = CNode.Next;
		DelNode = CNode.Next;
		CNode.Next = DelNode.Next;
		System.out.println(DelNode.Data + " is deleted");
		DelNode.Next = null;
		DelNode = null;
		Display();
	}
	int FindSum() {
		int sum = 0;
		CNode = Head;
		while(CNode!=null) {
			sum += CNode.Data;
			CNode = CNode.Next;
		}
		System.out.println("Sum is " + sum);
		return sum;
	}
	void FindAvg() {
		if(Head==null)
			System.out.println("Linked list is empty");
		else {
			double avg = (double)FindSum()/CountNodes();
			System.out.println("Average is " + avg);
		}
	}
	void FindMin() {
		if(Head==null)
			System.out.println("Linked list is empty");
		else {
			int min = Head.Data;
			CNode = Head;
			while(CNode!=null) {
				if(CNode.Data<min)
					min = CNode.Data;
				CNode = CNode.Next;
			}
			System.out.println("Min value is " + min);
		}
	}
	void FindMax() {
		if(Head==null)
			System.out.println("Linked list is empty");
		else {
			int max = Head.Data;
			CNode = Head;
			while(CNode!=null) {
				if(CNode.Data>max)
					max = CNode.Data;
				CNode = CNode.Next;
			}
			System.out.println("Max value is " + max);
		}
	}
	void Search() {
		if(Head==null) {
			System.out.println("Linked list is empty");
			return;
		}
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter search data");
		int search = sc.nextInt();
		int Count = 1;
		CNode = Head;
		while (CNode!=null) {
			if (CNode.Data==search) {
				System.out.println("Data found at position "+ Count);
				return;
			}
			CNode = CNode.Next;
			Count++;
		}
		System.out.println("Data not found");
	}
	void Update() {
		if(Head==null) {
			System.out.println("Linked list is empty");
			return;
		}
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter search data");
		int search = sc.nextInt();
		CNode = Head;
		while (CNode!=null) {
			if (CNode.Data==search) {
				System.out.println("Enter new data");
				CNode.Data = sc.nextInt();
				System.out.println("Data updated");
				Display();
				return;
			}
			CNode = CNode.Next;
		}
		System.out.println("Data not found");
	}
}
public class single_linked_list {

	public static void main(String[] args) {
		SingleLinkedList ob = new SingleLinkedList();
		ob.CreateList();
		Scanner sc = new Scanner(System.in);
		int opt;
			System.out.println("\n1.AddBegin\n2.AddEnd\n3.AddMiddle\n4.CountNodes\n5.DelBegin\n6.DelLast\n7.DelMiddle\n8.Search\n9.Update\n10.FindSum\n11.FindAvg\n12.FindMax\n13.FindMin");
			opt = sc.nextInt();
			switch(opt){
				case 1: ob.AddBegin(); break;
				case 2: ob.AddEnd(); break;
				case 3: ob.AddMiddle(); break;
				case 4: ob.CountNodes(); break;
				case 5: ob.DelBegin(); break;
				case 6: ob.DelLast(); break;
				case 7: ob.DelMiddle(); break;
				case 8: ob.Search(); break;
				case 9: ob.Update(); break;
				case 10: ob.FindSum(); break;
				case 11: ob.FindAvg(); break;
				case 12: ob.FindMax(); break;
				case 13: ob.FindMin(); break;
			}
	}
}

